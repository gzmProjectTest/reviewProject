1. 安装package
npm init -y

2. 安装express相关环境
  express -e          yes
  
3. 安装依赖包
  npm install

4. 启动
  npm run start